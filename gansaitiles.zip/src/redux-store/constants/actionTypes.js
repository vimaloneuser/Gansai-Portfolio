const actionTypes = {
    LOGIN: `LOGIN`,
    REGISTER: `REGISTER`,
    PROFILE: `PROFILE`,
}

export default actionTypes;