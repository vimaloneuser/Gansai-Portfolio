const servicesEndpoint = {
    login: 'login',
    register: 'register',
    profile: 'profile'
}

export default servicesEndpoint;