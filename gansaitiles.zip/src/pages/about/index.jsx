import React from "react";
import About from "../../components/About";

const AboutPage = () => {
  return (
    <React.Fragment>
      <About />
    </React.Fragment>
  );
};

export default AboutPage;
