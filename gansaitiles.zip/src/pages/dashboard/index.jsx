import React from "react";

const Dashboard = () => {
  return (
    <React.Fragment>
     <main role="main" className="mt-lg-5 m-0">
       <section className="wt-section" id="services">
        <div className="container">
          <div
            className="row justify-content-md-center text-center pb-lg-4 mb-lg-5 mb-4"
          >
            <div className="col-md-8 text-center w-md-50 mx-auto mb-0">
              <h2 className="mb-md-2">Our Services</h2>
              <p className="lead text-muted">
                WenTo creative technology company providing key digital services
                for everyone.
              </p>
            </div>
          </div>
          <div className="row">
            <div
              className="col-lg-4 mb-5 mb-lg-0 text-center"
              data-aos="fade-up"
              data-aos-easing="linear"
              data-aos-delay="100"
            >
              <div className="d-block mb-4">
                <img
                  src="assets/img/services/4.svg"
                  width="85px"
                  className="pr-4"
                  alt=""
                />
              </div>
              <h4 className="h5">Home Interior</h4>
              <p>
                Achieve virtually any look and layout design within one UI Kit
                solution.
              </p>
            </div>

            <div
              className="col-lg-4 mb-5 mb-lg-0 text-center"
              data-aos="fade-up"
              data-aos-easing="linear"
              data-aos-delay="200"
            >
              <div className="d-block mb-4">
                <img
                  src="assets/img/services/1.svg"
                  width="85px"
                  className="pr-4"
                  alt=""
                />
              </div>
              <h4 className="h5">Custom Design</h4>
              <p>
                We strive to figure out ways to help your audience grow through
                all platforms.
              </p>
            </div>

            <div
              className="col-lg-4 mb-5 mb-lg-0 text-center"
              data-aos="fade-up"
              data-aos-easing="linear"
              data-aos-delay="300"
            >
              <div className="d-block mb-4">
                <img
                  src="assets/img/services/5.svg"
                  width="85px"
                  className="pr-4"
                  alt=""
                />
              </div>
              <h4 className="h5">Business Interior</h4>
              <p>
                Find what you need in one template and combine features at will.
              </p>
            </div>
          </div>

          <hr className="my-5" />

          <div className="row">
            <div
              className="col-lg-4 mb-5 mb-lg-0 text-center"
              data-aos="fade-up"
              data-aos-easing="linear"
              data-aos-delay="400"
            >
              <div className="d-block mb-4">
                <img
                  src="assets/img/services/3.svg"
                  width="85px"
                  className="pr-4"
                  alt=""
                />
              </div>
              <h4 className="h5">Security Setup</h4>
              <p>
                Easy and fast adjustments of elements are possible with WenTo UI
                Kit.
              </p>
            </div>

            <div
              className="col-lg-4 mb-5 mb-lg-0 text-center"
              data-aos="fade-up"
              data-aos-easing="linear"
              data-aos-delay="500"
            >
              <div className="d-block mb-4">
                <img
                  src="assets/img/services/6.svg"
                  width="85px"
                  className="pr-4"
                  alt=""
                />
              </div>
              <h4 className="h5">Custom Paint</h4>
              <p>
                Our React Powered App will save you tons of time and cost in
                your projects.
              </p>
            </div>

            <div
              className="col-lg-4 mb-5 mb-lg-0 text-center"
              data-aos="fade-up"
              data-aos-easing="linear"
              data-aos-delay="600"
            >
              <div className="d-block mb-4">
                <img
                  src="assets/img/services/2.svg"
                  width="85px"
                  className="pr-4"
                  alt=""
                />
              </div>
              <h4 className="h5">Home Decor</h4>
              <p>
                Power your app with Angular components for no cost within one
                stop solution.
              </p>
            </div>
          </div>
        </div>
      </section> 

      <section className="wt-section bg-light" id="about">
        <div className="container">
          <div
            className="row justify-content-md-center text-center pb-lg-4 mb-lg-5 mb-4"
          >
            <div className="col-md-8 text-center w-md-50 mx-auto mb-0">
              <h2 className="mb-md-2">About Us</h2>
              <p className="lead text-muted">
                Desining Tiles import and export company. 
              </p>
            </div>
          </div>
          <div
            className="row justify-content-between align-items-center"
            data-aos="fade-right"
            data-aos-easing="linear"
            data-aos-delay="200"
          >
            <div className="col-md-5">
              <img
                src="assets/img/about/1.jpg"
                width="90%"
                className="rounded-md"
                alt=""
              />
            </div>
            <div className="col-md-7">
              <h3 className="mb-4">Who We Are</h3>
              <p className="text-muted">
                Gansai Tiles is one of the largest exporter of Ceramic Wall tiles and porcelain tiles in India. Our Manufacturing units are equipped with modern technology for zero chance for human error. These makes us different in the tiles industries. As we have highly innovative and aggressive development team so we are achieving target for quality and design for all countries in the world.

                Gansai Tiles is very prestigious brand of tiles industries. So we know the how to deliver Quality And Service and make Our Brand BIGGER & BETTER.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="wt-section">
        <div className="container">
          <div
            className="row justify-content-between align-items-center"
            data-aos="fade-left"
            data-aos-easing="linear"
            data-aos-delay="400"
          >
            <div className="col-md-7">
              <h3 className="mb-4">Our Mission and Goals</h3>
              <p className="text-muted">
                We want to give best product to our Customers.
              </p>
            </div>

            <div className="col-md-5">
              <img
                src="assets/img/about/2.jpg"
                width="90%"
                className="rounded-md"
                alt=""
              />
            </div>
          </div>
        </div>
      </section>
      

      <section className="wt-section" id="portfolio">
        <div className="container">
          <div className="row justify-content-md-center text-center pb-lg-5">
            <div className="col-md-12">
              <h2 className="h1">Portfolio</h2>
              <p>Here you can see some of our designs.</p>
            </div>
          </div>
          <div
            className="portfolio-item row"
            data-aos="fade-up"
            data-aos-easing="linear"
            data-aos-delay="100"
          >
            <div className="item gts col-lg-3 col-md-4 col-6 col-sm">
              <div className="hovereffect5 rounded-md overflow-hidden">
                <img
                  className="img-fluid img-responsive"
                  src="assets/img/portfolio/img1.jpg"
                  alt=""
                />
                <div className="overlay">
                  <p>
                    <a
                      href="assets/img/portfolio/img1.jpg"
                      className="fancylight popup-btn info"
                      data-fancybox-group="light"
                      ><i>view</i></a
                    >
                  </p>
                </div>
              </div>
            </div>
            <div className="item selfie col-lg-3 col-md-4 col-6 col-sm">
              <div className="hovereffect5 rounded-md overflow-hidden">
                <img
                  className="img-fluid img-responsive"
                  src="assets/img/portfolio/img2.jpg"
                  alt=""
                />
                <div className="overlay">
                  <p>
                    <a
                      href="assets/img/portfolio/img2.jpg"
                      className="fancylight popup-btn info"
                      data-fancybox-group="light"
                      ><i>view</i></a
                    >
                  </p>
                </div>
              </div>
            </div>
            <div className="item lap col-lg-3 col-md-4 col-6 col-sm">
              <div className="hovereffect5 rounded-md overflow-hidden">
                <img
                  className="img-fluid img-responsive"
                  src="assets/img/portfolio/img3.jpg"
                  alt=""
                />
                <div className="overlay">
                  <p>
                    <a
                      href="assets/img/portfolio/img3.jpg"
                      className="fancylight popup-btn info"
                      data-fancybox-group="light"
                      ><i>view</i></a
                    >
                  </p>
                </div>
              </div>
            </div>
            <div className="item selfie col-lg-3 col-md-4 col-6 col-sm">
              <div className="hovereffect5 rounded-md overflow-hidden">
                <img
                  className="img-fluid img-responsive"
                  src="assets/img/portfolio/img4.jpg"
                  alt=""
                />
                <div className="overlay">
                  <p>
                    <a
                      href="assets/img/portfolio/img4.jpg"
                      className="fancylight popup-btn info"
                      data-fancybox-group="light"
                      ><i>view</i></a
                    >
                  </p>
                </div>
              </div>
            </div>
            <div className="item lap col-lg-3 col-md-4 col-6 col-sm">
              <div className="hovereffect5 rounded-md overflow-hidden">
                <img
                  className="img-fluid img-responsive"
                  src="assets/img/portfolio/img5.jpg"
                  alt=""
                />
                <div className="overlay">
                  <p>
                    <a
                      href="assets/img/portfolio/img5.jpg"
                      className="fancylight popup-btn info"
                      data-fancybox-group="light"
                      ><i>view</i></a
                    >
                  </p>
                </div>
              </div>
            </div>
            <div className="item gts col-lg-3 col-md-4 col-6 col-sm">
              <div className="hovereffect5 rounded-md overflow-hidden">
                <img
                  className="img-fluid img-responsive"
                  src="assets/img/portfolio/img6.jpg"
                  alt=""
                />
                <div className="overlay">
                  <p>
                    <a
                      href="assets/img/portfolio/img6.jpg"
                      className="fancylight popup-btn info"
                      data-fancybox-group="light"
                      ><i>view</i></a
                    >
                  </p>
                </div>
              </div>
            </div>
            <div className="item gts col-lg-3 col-md-4 col-6 col-sm">
              <div className="hovereffect5 rounded-md overflow-hidden">
                <img
                  className="img-fluid img-responsive"
                  src="assets/img/portfolio/img7.jpg"
                  alt=""
                />
                <div className="overlay">
                  <p>
                    <a
                      href="assets/img/portfolio/img7.jpg"
                      className="fancylight popup-btn info"
                      data-fancybox-group="light"
                      ><i>view</i></a
                    >
                  </p>
                </div>
              </div>
            </div>
            <div className="item selfie col-lg-3 col-md-4 col-6 col-sm">
              <div className="hovereffect5 rounded-md overflow-hidden">
                <img
                  className="img-fluid img-responsive"
                  src="assets/img/portfolio/img8.jpg"
                  alt=""
                />
                <div className="overlay">
                  <p>
                    <a
                      href="assets/img/portfolio/img8.jpg"
                      className="fancylight popup-btn info"
                      data-fancybox-group="light"
                      ><i>view</i></a
                    >
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>


      <section className="bg-dark position-relative pt-5">
        <div className="container">
          <div className="row text-center text-uppercase text-white">
            <div className="col-lg-3 col-sm-6 pb-5">
              <h5 className="js-counter display-4 mb-1">2</h5>
              <small
                className="d-block font-style-normal text-uppercase wt-letter-spacing-sm"
                >Year Experience</small
              >
            </div>

            <div className="col-lg-3 col-sm-6 pb-5">
              <h5 className="js-counter display-4 mb-1">2</h5>
              <small
                className="d-block font-style-normal text-uppercase wt-letter-spacing-sm"
                >Countries</small
              >
            </div>

            <div className="col-lg-3 col-sm-6 pb-5">
              <h5 className="js-counter display-4 mb-1">245</h5>
              <small
                className="d-block font-style-normal text-uppercase wt-letter-spacing-sm"
                >Happy Customers</small
              >
            </div>

            <div className="col-lg-3 col-sm-6 pb-5">
              <h5 className="js-counter display-4 mb-1">30</h5>
              <small
                className="d-block font-style-normal text-uppercase wt-letter-spacing-sm"
                >Design</small
              >
            </div>
          </div>
        </div>
      </section>

      <section className="wt-section bg-light" id="contact">
        <div className="container">
          <div
            className="row justify-content-md-center text-center pb-lg-4 mb-lg-5 mb-4"
          >
            <div className="col-md-8 text-center w-md-50 mx-auto mb-0">
              <h2 className="mb-md-2">Feel free to contact us</h2>
             <p>
                There are many variations of passages of Lorem Ipsum available,
                but the majority
              </p> 
            </div>
          </div>

          <div className="row justify-content-md-center text-center mg-5 pb-5">
            <div className="col-md-7">
              <div className="form">
                <form
                  name="sentMessage"
                  className="well"
                  id="contactForm"
                  noValidate
                  data-aos="fade-up"
                  data-aos-easing="linear"
                  data-aos-delay="200"
                >
                  <div className="control-group">
                    <div className="form-group mb-4">
                      <input
                        type="text"
                        className="form-control form-control-lg"
                        placeholder="Full Name"
                        id="name"
                        required
                        data-validation-required-message="Please enter your name"
                      />
                      <p className="help-block"></p>
                    </div>
                  </div>
                  <div className="form-group mb-4">
                    <div className="controls">
                      <input
                        type="email"
                        className="form-control form-control-lg"
                        placeholder="Email"
                        id="email"
                        required
                        data-validation-required-message="Please enter your email"
                      />
                    </div>
                  </div>

                  <div className="form-group mb-4">
                    <div className="controls">
                      <textarea
                        rows="10"
                        cols="100"
                        className="form-control form-control-lg"
                        placeholder="Message"
                        id="message"
                        required
                        data-validation-required-message="Please enter your message"
                        minLength="5"
                        data-validation-minlength-message="Min 5 characters"
                        maxLength="999"
                      ></textarea>
                    </div>
                  </div>
                  <div id="success"></div>
                  <div className="text-center">
                    <button
                      className="btn btn-lg btn-primary py-3 mt-3 px-4 btn-pill"
                      type="submit"
                    >
                      Send Your Message
                    </button>
                  </div>
                </form>
              </div>
            </div>
            <div className="col-md-5">
              <div className="row contact-info">
                <div className="col-md-12">
                  <div
                    className="bg-white p-4 d-flex mb-md-4 border rounded-md"
                    data-aos="fade-right"
                    data-aos-easing="linear"
                    data-aos-delay="200"
                  >
                    <i className="fa fa-address-book mt-md-1 text-primary pr-4"></i>
                    <div className="text-left">
                      <h6 className="mb-2">Address</h6>
                      <p className="text-muted">132 Manhatten Str., NewYork, US</p>
                    </div>
                  </div>

                  <div
                    className="bg-white p-4 d-flex mb-md-4 border rounded-md"
                    data-aos="fade-right"
                    data-aos-easing="linear"
                    data-aos-delay="300"
                  >
                    <i
                      className="fas fa-envelope-open mt-md-1 text-primary pr-4"
                    ></i>
                    <div className="text-left">
                      <h3 className="h5">Email</h3>
                      <p className="mb-0">mail@webthemez.com</p>
                    </div>
                  </div>

                  <div
                    className="bg-white p-4 d-flex mb-md-4 border rounded-md"
                    data-aos="fade-right"
                    data-aos-easing="linear"
                    data-aos-delay="400"
                  >
                    <i className="fa fa-phone mt-md-1 text-primary pr-4"></i>
                    <div className="text-left">
                      <h3 className="h5">Phone Number</h3>
                      <p className="mb-0">1-234-567-2401</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div
            className="row"
            data-aos="fade-up"
            data-aos-easing="linear"
            data-aos-delay="100"
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d11880.492291371422!2d12.4922309!3d41.8902102!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x28f1c82e908503c4!2sColosseo!5e0!3m2!1sit!2sit!4v1524815927977"
              width="100%"
              height="320"
              frameBorder="0"
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </section>

    </main>
    </React.Fragment>
  );
};

export default Dashboard;
