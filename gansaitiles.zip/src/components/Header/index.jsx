import React from "react";
// import { Link, useParams } from "react-router-dom";

const Header = () => {
  // const params = useParams();
  return (
    <header id="top">
      <nav
        className="navbar navbar-expand-lg navbar-dark bg-white fixed-top"
        id="mainNav"
      >
        <div className="container">
          <a className="navbar-brand js-scroll-trigger" href="#page-top"
            >Gansai<span>Tiles</span></a
          >
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarResponsive"
            aria-controls="navbarResponsive"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="ti-menu"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarResponsive">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item">
                <a className="nav-link js-scroll-trigger" href="#top">Home</a>
              </li>
              <li className="nav-item">
                <a className="nav-link js-scroll-trigger" href="#about">About</a>
              </li>
              <li className="nav-item">
                <a className="nav-link js-scroll-trigger" href="#portfolio"
                  >Portfolio
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link js-scroll-trigger" href="#contact"
                  >Contact</a
                >
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <section className="hero-large hero">
        <div id="demo" className="carousel slide" data-ride="carousel">
          <ul className="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" className="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
          </ul>
          <div className="carousel-inner">
            <div className="carousel-item active">
              <img
                src="assets/img/intro/banner-bg1.png"
                alt="Los Angeles"
                width="1100"
                height="500"
              />
              <div className="container">
                <div className="carousel-caption">
                  <h2>LightUp Your Design</h2>
                  <p>Extra Special Touch</p>
                </div>
              </div>
            </div>
            <div className="carousel-item">
              <img
                src="assets/img/intro/banner-bg2.png"
                alt="Chicago"
                width="1100"
                height="500"
              />
              <div className="container">
                <div className="carousel-caption">
                  <h2>Get Your Dream Light</h2>
                  <p>Décor with Charming</p>
                </div>
              </div>
            </div>
            <div className="carousel-item">
              <img
                src="assets/img/intro/banner-bg3.png"
                alt="New York"
                width="1100"
                height="500"
              />
              <div className="container">
                <div className="carousel-caption">
                  <h2>Feel The Natural Beauty</h2>
                  <p>Modern-edge Design</p>
                </div>
              </div>
            </div>
          </div>
          <a className="carousel-control-prev" href="#demo" data-slide="prev">
            <span className="carousel-control-prev-icon"></span>
          </a>
          <a className="carousel-control-next" href="#demo" data-slide="next">
            <span className="carousel-control-next-icon"></span>
          </a>
        </div>
     
      </section>
    </header>
  );
};

export default Header;
