import React from "react";
const Footer = () => {
  return (
    <footer className="bg-dark py-5">
    <div className="container">
      <div className="row">
        <div className="col-md-8 text-center text-md-left mb-3 mb-md-0">
          <small className="text-white"
            >
            GansaiTiles <br />&copy; All Rights Reserved</small
          >
        </div>

        <div className="col-md-4 align-self-center">
          <ul className="list-inline text-center text-md-right mb-0">
            <li
              className="list-inline-item mx-2"
              data-toggle="tooltip"
              data-placement="top"
              title="Facebook"
            >
              <a
                className="text-white"
                target="_blank"
                rel="noreferrer"
                href="https://www.facebook.com/Maxi"
              >
                <i className="fab fa-facebook"></i>
              </a>
            </li>
            <li
              className="list-inline-item mx-2"
              data-toggle="tooltip"
              data-placement="top"
              title="Instagram"
            >
              <a
                className="text-white"
                target="_blank"
                rel="noreferrer"
                href="https://www.instagram.com/Maxi"
              >
                <i className="fab fa-instagram"></i>
              </a>
            </li>
            <li
              className="list-inline-item mx-2"
              data-toggle="tooltip"
              data-placement="top"
              title="Twitter"
            >
              <a
                className="text-white"
                target="_blank"
                rel="noreferrer"
                href="https://twitter.com/Maxi"
              >
                <i className="fab fa-twitter"></i>
              </a>
            </li>
            <li
              className="list-inline-item mx-2"
              data-toggle="tooltip"
              data-placement="top"
              title="Dribbble"
            >
              <a
                className="text-white"
                target="_blank"
                rel="noreferrer"
                href="https://dribbble.com/Maxi"
              >
                <i className="fab fa-dribbble"></i>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </footer>
  );
};

export default Footer;
